<div class="card shadow-sm">
    <div class="card-header">
        <h3 class="card-title">Edit Profile</h3>
        <div class="card-toolbar">
      
        </div>
    </div>
    <div class="card-body">

    <?php foreach ($data['studentProfile'] as $studentProfile) :?>
        <?php endforeach;?>
    
                                  
    <form action="<?php echo URLROOT; ?>/pages/edit_profile" method="POST" class="form" enctype="multipart/form-data" id="kt_account_profile_details_form">
    <div class="card-body border-top p-9">
        <!-- Avatar Section -->
        <div class="row mb-6">
            <label class="col-lg-4 col-form-label fw-semibold fs-6">Avatar</label>
            <div class="col-lg-8">
                <div class="image-input image-input-outline" data-kt-image-input="true" style="background-image: url('<?php echo URLROOT."/public/".$studentProfile->st_image; ?>')">
                    <div class="image-input-wrapper w-125px h-125px" style="background-image: url('<?php echo URLROOT."/public/".$studentProfile->st_image; ?>')"></div>
                    <label class="btn btn-icon btn-circle btn-active-color-primary w-25px h-25px bg-body shadow" data-kt-image-input-action="change" data-bs-toggle="tooltip" title="Change avatar">
                        <i class="ki-duotone ki-pencil fs-7"></i>
                        <input type="file" name="file" accept=".png, .jpg, .jpeg" />
                        <input type="hidden" name="profile_avatar_remove" />
                    </label>
                    <span class="btn btn-icon btn-circle btn-active-color-primary w-25px h-25px bg-body shadow" data-kt-image-input-action="cancel" data-bs-toggle="tooltip" title="Cancel avatar">
                        <i class="ki-duotone ki-cross fs-2"></i>
                    </span>
                    <span class="btn btn-icon btn-circle btn-active-color-primary w-25px h-25px bg-body shadow" data-kt-image-input-action="remove" data-bs-toggle="tooltip" title="Remove avatar">
                        <i class="ki-duotone ki-cross fs-2"></i>
                    </span>
                </div>
                <div class="form-text">Allowed file types: png, jpg, jpeg.</div>
            </div>
        </div>

        <!-- Full Name Section -->
        <div class="row mb-6">
            <label class="col-lg-4 col-form-label required fw-semibold fs-6">Full Name</label>
            <div class="col-lg-8">
                <input class="form-control form-control-lg form-control-solid" name="st_fullname" type="text" required value="<?php echo $studentProfile->st_fullname; ?>" />
            </div>
        </div>

        <!-- IC Number Section -->
        <div class="row mb-6">
            <label class="col-lg-4 col-form-label required fw-semibold fs-6">IC Number</label>
            <div class="col-lg-8">
                <input class="form-control form-control-lg form-control-solid" name="st_ic" type="text" required value="<?php echo $studentProfile->st_ic; ?>" />
            </div>
        </div>

        <!-- Email Address Section -->
        <div class="row mb-6">
            <label class="col-lg-4 col-form-label required fw-semibold fs-6">Email Address</label>
            <div class="col-lg-8">
                <input class="form-control form-control-lg form-control-solid" name="st_email" type="text" readonly value="<?php echo $studentProfile->st_email; ?>" />
            </div>
        </div>

        <!-- Gender Section -->
        <div class="row mb-6">
            <label class="col-lg-4 col-form-label required fw-semibold fs-6">Gender</label>
            <div class="col-lg-8">
                <select class="form-select form-select-solid form-select-lg" name="st_gender">
                    <option value="<?php echo $studentProfile->st_gender ?>"><?php echo $studentProfile->st_gender ?></option>
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                </select>
            </div>
        </div>

        <!-- Race Section -->
        <div class="row mb-6">
            <label class="col-lg-4 col-form-label required fw-semibold fs-6">Race</label>
            <div class="col-lg-8">
                <select class="form-select form-select-solid form-select-lg" name="st_race">
                    <option value="<?php echo $studentProfile->st_race ?>"><?php echo $studentProfile->st_race ?></option>
                    <option value="Malay">Malay</option>
                    <option value="Malay">India</option>
                    <option value="Malay">Chinese</option>
                    <option value="Malay">Others</option>
                    <!-- Additional options here -->
                </select>
            </div>
        </div>

        <!-- Institution of Higher Learning Section -->
        <div class="row mb-6">
            <label class="col-lg-4 col-form-label required fw-semibold fs-6">Institution of Higher Learning</label>
            <div class="col-lg-8">
                <select class="form-select form-select-solid form-select-lg" name="univ_code">
                    <option value="UTM">UTM</option>
                    <option value="Malay">UKM</option>
                    <option value="Malay">UM</option>
                    <option value="Malay">USM</option>
                    <option value="Malay">UPM</option>
                    <option value="Malay">UITM</option>
                    <option value="Malay">UIAM</option>
                    <option value="Malay">UUM</option>
                    <option value="Malay">UNIMAS</option>
                    <option value="Malay">UMS</option>
                    <option value="Malay">UPSI</option>
                    <option value="Malay">USIM</option>
                    <option value="Malay">UMT</option>
                    <option value="Malay">UTHM</option>
                    <option value="Malay">UMPSA</option>
                    <option value="Malay">UniMAP</option>
                    <option value="Malay">UniSZA</option>
                    <option value="Malay">UMK</option>
                    <option value="Malay">UPNM</option>
                    <!-- Additional options here -->
                </select>
            </div>
        </div>

        <!-- Address Section -->
        <div class="row mb-6">
            <label class="col-lg-4 col-form-label required fw-semibold fs-6">Address</label>
            <div class="col-lg-8">
                <textarea class="form-control form-control-solid" name="st_address" rows="3" required><?php echo $studentProfile->st_address ?></textarea>
            </div>
        </div>

        <!-- Submit Button -->
        <div class="card-footer d-flex justify-content-end py-6 px-9">
            <input type="hidden" id="update_student" name="update_student" value="update_student">
            <button type="submit" name="submit" class="btn btn-primary">Update</button>
        </div>
    </div>
</form>


    </div>
    <div class="card-footer">
        Footer
    </div>
</div>